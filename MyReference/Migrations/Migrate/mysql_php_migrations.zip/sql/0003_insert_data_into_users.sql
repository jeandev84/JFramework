﻿-- Добавляем тестовых пользователей --
insert into `users` (`email`, `password`) values 
    ('test1@gmail.com', '111111'),
    ('test2@gmail.com', '222222'),
    ('test3@gmail.com', '333333')